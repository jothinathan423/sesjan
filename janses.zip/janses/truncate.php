<?php
session_start();

include 'configuration.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Update a particular column in the 'students' table
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $truncateValue = ''; // Set this to the value you want to set the column to (e.g., empty string, NULL)

    $sql = "UPDATE students SET credit_points=?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $truncateValue);

    if ($stmt->execute()) {
        // Column truncated successfully
        echo "Column truncated successfully.";
    } else {
        echo "Error truncating column: " . $stmt->error;
    }

    $stmt->close();
}

// Truncate the 'id_cards' table using PDO
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    
    $tableName = 'student_activities';
    
    $pdo->exec("TRUNCATE TABLE $tableName");
    
    echo "Table $tableName truncated successfully.";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn->close();
?>
