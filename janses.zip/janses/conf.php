<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'id21582438_id21538442_sesta';
?>