<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "id21582438_id21538442_sesta";


?>