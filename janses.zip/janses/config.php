<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "id21582438_id21538442_sesta";

$conn = new mysqli($hostname, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
